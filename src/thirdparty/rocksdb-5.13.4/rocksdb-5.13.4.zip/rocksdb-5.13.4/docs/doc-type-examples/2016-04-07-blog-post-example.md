---
title: Blog Post Example
layout: post
author: exampleauthor
category: blog
---

Any local blog posts would go in the `_posts` directory.

This is an example blog post introduction, try to keep it short and about a paragraph long, to encourage people to click through to read the entire post.

<!--truncate-->

Everything below the `<!--truncate-->` tag will only show on the actual blog post page, not on the `/blog/` index.

Author is defined in `_data/authors.yml`


## No posts?

If you have no blog for your site, you can remove the entire `_posts` folder. Otherwise add markdown files in here. See CONTRIBUTING.md for details.
